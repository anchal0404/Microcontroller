/* 
 * File:   digital_keypad.h
 * Author: Anchal Rathore
 *
 * Created on 22 November, 2023, 5:34 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H


void init_digital_keypad(void); 

#endif	/* DIGITAL_KEYPAD_H */

